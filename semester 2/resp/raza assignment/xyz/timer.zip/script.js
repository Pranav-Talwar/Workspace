const display = document.getElementById("display");
const timeButtons = document.getElementById("timeButtons");
const controlButtons = document.getElementById("controlButtons");
const endSound = document.getElementById("endSound"); // Reference to the audio element

let timer = null;
let startTime = 0;
let elapsedTime = 0;
let isRunning = false;

function startTimer(seconds) {
    startTime = seconds * 1000;
    elapsedTime = startTime;
    updateDisplay();

    // Play sound when a timer is selected
    endSound.play();

    // Hide time buttons, show control buttons
    timeButtons.style.display = "none";
    controlButtons.style.display = "flex";

    // Start countdown
    if (!isRunning) {
        timer = setInterval(updateTimer, 1000);
        isRunning = true;
    }
}

function updateTimer() {
    elapsedTime -= 1000;
    updateDisplay();

    if (elapsedTime <= 0) {
        clearInterval(timer);
        isRunning = false;
        elapsedTime = 0;
        endSound.play(); // Play sound when timer stops
    }
}

function pauseTimer() {
    if (isRunning) {
        clearInterval(timer);
        isRunning = false;
        document.getElementById("pauseBtn").textContent = "Resume";
    } else {
        timer = setInterval(updateTimer, 1000);
        isRunning = true;
        document.getElementById("pauseBtn").textContent = "Pause";
    }
}

function resetTimer() {
    clearInterval(timer);
    isRunning = false;
    elapsedTime = 0;
    updateDisplay();

    // Reset button text
    document.getElementById("pauseBtn").textContent = "Pause";

    // Show time buttons, hide control buttons
    timeButtons.style.display = "flex";
    controlButtons.style.display = "none";
}

function addThirtySeconds() {
    // Add 30 seconds (30000 ms) to the current elapsedTime
    elapsedTime += 30000;
    updateDisplay();
}

function updateDisplay() {
    const minutes = String(Math.floor(elapsedTime / 60000)).padStart(2, "0");
    const seconds = String(Math.floor((elapsedTime % 60000) / 1000)).padStart(2, "0");
    display.textContent = `${minutes}:${seconds}`;
}
