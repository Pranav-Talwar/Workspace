$('.value-link').on('click', function (event) {
    event.preventDefault(); // Prevent default link behavior

    // Get the related text from the clicked link's data-text attribute
    var newText = $(this).data('text');

    // Update the text content in the dynamic text container
    $('#dynamic-text').text(newText);
    
});
