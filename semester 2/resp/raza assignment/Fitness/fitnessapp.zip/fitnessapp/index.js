// Select all value links and the image element
$('.value-link').on('click', function(event) {
    event.preventDefault(); // Prevent the default link behavior

    // Get the image file path from the clicked link's data-image attribute
    var imageFile = $(this).data('image');

    // Change the src of the image to the new one
    $('#dynamic-image').attr('src', imageFile);
});
